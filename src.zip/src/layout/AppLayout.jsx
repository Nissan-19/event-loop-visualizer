import CodePanel from "../component/CodePanel"
import Header from "../component/Header"
import LessonSelector from "../component/LessonSelector"
import RuntimeBoard from "../component/runtime/RuntimeBoard"


function AppLayout (){
  return (
    <div>
      
      <Header/>
        <main className="grid lg:grid-cols-4 items-start gap-2 p-2 ">
          <div className="border" > 
            <LessonSelector/>
            <CodePanel/>
            plackback
          </div>

          <div className="lg:col-span-2 border">
            <RuntimeBoard/>
            message 
          </div>

          <div className="border">
            guess
            output
          </div>
        </main>
    </div>

    
    
  )
}

export default AppLayout
