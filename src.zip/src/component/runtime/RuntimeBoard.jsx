import CallStack from "./CallStack"
import BrowserAPIs from "./BrowserAPIs"
import TaskQueue from "./TaskQueue"
import MicrotaskQueue from "./MicrotaskQueue"

function RuntimeBoard() {
  return (
    <section className="w-full border border-slate-300 min-h-140 rounded-xl p-2">
        <h2>
            JavaScript Runtime
        </h2>
        
        <CallStack/>
        <BrowserAPIs/>
        <TaskQueue/>
        <MicrotaskQueue/>
        <p>event loop</p>
    </section>
  )
}

export default RuntimeBoard
