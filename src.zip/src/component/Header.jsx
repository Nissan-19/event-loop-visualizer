import logo from "../assets/images/logo.png"

function Header () {


  return (
    <header className="flex px-3 mx items-center border-b border-slate-300">

        <img    className="w-10 h-10"
                src={logo} alt="Logo Image" />
        <div className="ml-1">
            <h1 className=" text-2xl font-semibold ">
                Event Loop Visualizer
            </h1>
            <p className="text-sm font-extralight">
                See how JavaScript executes code, one step at a time.
            </p>
        </div>
        <button className="ml-auto rounded-md border border-slate-300 px-3 py-2 text-sm">
            theme
        </button>
    </header>
  )
}

export default Header
